
#' Pre-processed Englert and Kieser (2013)'s optimal adaptive designs.
#'
#' A dataframe containing all the designd in \code{\link{EKOptAdaptDesigns}}
#'pre-processed by the function \code{\link{dsgnPrep}}, the the argument
#'\code{w1} set to "n".
#'
#' @format A dataframe with 709 rows and 20 variables.
"EKOADwn"
